/*****************************************************
 *  
 *   Title: MethodsPractice
 *   Author: Mick M. Mouse
 *   Date: October, 2024
 *   Purpose: Demonstrate the creation and use
 *   of Java methods().
 *   
 *  
 *****************************************************/
package methodspractice;

import java.util.Scanner;

public class MethodsPractice 
{
    //*************************************************/
    public static void main(String[] args) 
    {
        keepGoing();
    } // END OF main() METHOD.
    
    public static void keepGoing()
    {
        Scanner sam = new Scanner(System.in);
        
        String strKeepGoing = "y";
        
        while(strKeepGoing.equalsIgnoreCase("y"))
        {
            System.out.println("Would you like another run? ");
            strKeepGoing = sam.next();
        }
        
        // Write a method that accepts a floating-point number and squares it.
        // Write a method to get the dimensions of a rectangle.
        // Write a method to get the dimensions of a triangle.
        // Write a method to calculate the area of a rectangle.
        // Write a method to calculate the area of a triangle.
        // Write a method to calculate temperature converter.
        // Write a method to convert currency from dollars to 
        // Euros, British pounds and to Canadian dollars.
    } // END OF keepGoing() METHOD.
} // END OF CLASS.
 

